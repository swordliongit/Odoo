Birtum | Disable Debug Mode
-------------------------------
This module disables debug mode for users who do not have the "Enable debug mode" permission.
